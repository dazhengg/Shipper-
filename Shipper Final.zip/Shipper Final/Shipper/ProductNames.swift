//
//  ProductNames.swift
//  Shipper
//
//  Created by David Zheng on 7/22/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

import Foundation
import UIKit
struct ProductNames {
    private(set) public var title: String // item apple
    private(set) public var image: UIImage// pic of apple.
    private(set) public var unit: String
    private(set) public var price: Double
    
    
    init(title: String, image: UIImage, unit: String, price: Double ) {
        self.title = title
        self.image = image
        self.unit = unit
        self.price = price
    }
}
extension ProductNames {
    static func ==(lhs: ProductNames, rhs: ProductNames) -> Bool {
        return lhs.title == rhs.title && lhs.price == rhs.price && lhs.unit == rhs.unit
    }
}
extension ProductNames {
    func displayPrice() -> String {
        return String.init(format: "$ %.02f per %@", price, unit)
    }
}
