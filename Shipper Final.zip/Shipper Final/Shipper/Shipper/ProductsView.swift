//
//  ProductsView.swift
//  Shipper
//
//  Created by David Zheng on 7/22/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

import UIKit

class ProductsView: UIViewController {

    @IBOutlet weak var productsCollection: UICollectionView!
    
  
    
    @IBOutlet weak var collectionProd: UICollectionView!
    
    
    
    private(set) public var products = [ProductNames]()
    private(set) public var cart = Cart()
    private(set) public var productCell = "ProductsCell"
    
    var tapped: Bool = false
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cart.updateCart()
        self.navigationItem.rightBarButtonItem?.title = "Checkout (\(cart.items.count))"
        

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.rightBarButtonItem?.isEnabled = false
        self.navigationItem.rightBarButtonItem?.isEnabled = true
      
       
        
       
        
    }

  
    func initProducts(category: CategoryNames) {
        products = DataService.instance.getProducts(forCategoryTitl: category.title)
        navigationItem.title = category.title
    }
    
}
//extension ProductsView: CartDelegate {
//
//    func updateCart(cell: ProductsCell) {
//        guard let indexPath = .indexPath(for: UICollectionViewCell)
//
//    }
//
//    func didAddtoCart(cell: ProductsCell) {
//        <#code#>
//    }
//
//
//}




extension ProductsView: UICollectionViewDataSource, UICollectionViewDelegate,CartDelegate {
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showCart" {
            if let cartView = segue.destination as? CartView {
                cartView.cart = self.cart
            }
        }
    }
    func updateCart(cell: ProductsCell) {
        guard let indexPath = collectionProd.indexPath(for: cell)
            else { return}
        let product = products[indexPath.row]
        
        //Update Cart with product
        cart.updateCart(with: product)
        
        self.navigationItem.rightBarButtonItem?.title = "Checkout (\(cart.items.count))"
    }
    
    


    

    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
        
    }
    

    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductsCell", for: indexPath) as? ProductsCell {
            let product = products[indexPath.row]
            cell.delegate = self
//            cell.addButton(state: self.cart.contains(product: product) )
            cell.updateViews(product: product)
           
            
            
            return cell

        }
        else {
            return ProductsCell()
        }
    }
}


