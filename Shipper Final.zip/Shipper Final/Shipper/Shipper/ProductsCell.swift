//
//  ProductsCell.swift
//  Shipper
//
//  Created by David Zheng on 7/22/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

import UIKit


protocol CartDelegate {
    func updateCart(cell: ProductsCell)
//    func didAddtoCart(cell:ProductsCell)
    
}

    class ProductsCell: UICollectionViewCell {
        
        @IBOutlet weak var productTitle: UILabel!
        @IBOutlet weak var productImage: UIImageView!
        @IBOutlet weak var unit: UILabel!
        @IBOutlet weak var price: UILabel!
        
        @IBOutlet weak var addButton: UIButton!
        var delegate :CartDelegate?
        
      
        
        func updateViews(product: ProductNames) {
            
            productTitle.text = product.title
            productImage.image = product.image
            unit.text = product.unit
            price.text = String(format:"$%.2f",product.price)
            
            
        }
        
//        func setButton(state: Bool) {
//            addButton.isSelected = state
//            addButton.backgroundColor = (!addButton.isSelected) ? .black : .red
//        }
//
        @IBAction func addtoCart(_ sender: Any) {
//            setButton(state: !addButton.isSelected)
            if addButton.title(for: .normal) == "Add item" {
                addButton.setTitle("Remove", for: .normal)
                
            } else if addButton.title(for: .normal) == "Remove" {
                addButton.setTitle("Add item", for: .normal)
            }
            self.delegate?.updateCart(cell: self)
         
        }
        
    }
    

