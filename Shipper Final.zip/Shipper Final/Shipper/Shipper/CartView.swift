//
//  CartView.swift
//  Shipper
//
//  Created by David Zheng on 7/23/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

import UIKit


class CartView: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var totalLabel: UILabel!
    var cart: Cart? = nil
    let currencyCalc = CurrencyCalc(currency: 0  )
    
 
    override func viewDidLoad() {
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.totalLabel.text = (self.cart?.total.description)
        
    }
    
    



}
extension CartView: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (cart?.items.count)!
    }
    
 
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCartCell", for: indexPath) as! ItemCartCell
        
        if let cartItem = cart?.items[indexPath.item] {
            cell.delegate = self as? ItemCartDelegate
            
            cell.nameLabel.text = cartItem.product.title
            cell.priceLabel.text = cartItem.product.displayPrice()
            cell.quantityLabel.text = String(describing: cartItem.quantity)
            cell.quantity = cartItem.quantity
        }
        
        return cell
    }
    

}

extension CartView: ItemCartDelegate {
    func updateCartItem(cell: ItemCartCell, quantity: Int) {
        guard let indexPath = tableView.indexPath(for: cell) else { return }
        guard let cartItem = cart?.items[indexPath.row] else { return }
        
        cartItem.quantity = quantity
        
        guard let total = cart?.total else { return }
        totalLabel.text = currencyCalc.totalAmount(total: total, quantity: quantity )
    
    }
    
    
}
