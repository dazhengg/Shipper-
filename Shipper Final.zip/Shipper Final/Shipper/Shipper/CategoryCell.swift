//
//  CategoryCell.swift
//  Shipper
//
//  Created by David Zheng on 7/22/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

import UIKit

class CategoryCell: UITableViewCell {

    @IBOutlet weak var videoImageView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    func setCategory(category: CategoryNames) {
        videoImageView.image = category.image
        titleLabel.text = category.title
        
    }
    
}
