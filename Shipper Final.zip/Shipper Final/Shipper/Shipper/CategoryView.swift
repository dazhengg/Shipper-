//
//  CategoryView.swift
//  Shipper
//
//  Created by David Zheng on 7/22/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

import UIKit

class CategoryView:UIViewController {
    var cat_names: [CategoryNames] = []
    
    @IBOutlet weak var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cat_names = createArray()
    }
    
    func createArray() -> [CategoryNames] {
        var tempPic : [CategoryNames] = []
        let pic1 = CategoryNames(image: #imageLiteral(resourceName: "dairy"), title: "Dairy")
        let pic2 = CategoryNames(image: #imageLiteral(resourceName: "fruits"), title: "Fruit")
        let pic3 = CategoryNames(image: #imageLiteral(resourceName: "vegan"), title: "Vegan")
        
        tempPic.append(pic1)
        tempPic.append(pic2)
        tempPic.append(pic3)
        return tempPic
        
    }
}

extension CategoryView : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DataService.instance.getCategories().count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryCell") as? CategoryCell {
            let category = DataService.instance.getCategories()[indexPath.row]
            cell.setCategory(category: category)
            return cell
        } else {
            return CategoryCell()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let category = DataService.instance.getCategories()[indexPath.row]
        performSegue(withIdentifier: "ProductsView", sender: category)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let productsView = segue.destination as? ProductsView {
            let barBtn = UIBarButtonItem()
            barBtn.title = ""
            navigationItem.backBarButtonItem = barBtn
            assert(sender as? CategoryNames != nil)
            productsView.initProducts(category: sender as! CategoryNames)
            
        }
    }


}
