//
//  ItemCart.swift
//  Shipper
//
//  Created by David Zheng on 7/23/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

import Foundation

class ItemCart {
    var quantity : Int = 1
    var product : ProductNames
    
    var curTotal : Double { get { return Double(product.price) * Double(quantity) } }
    
    init(product: ProductNames) {
        self.product = product
    }
    
    
}
