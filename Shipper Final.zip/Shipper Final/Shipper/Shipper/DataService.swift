//
//  DataService.swift
//  Shipper
//
//  Created by David Zheng on 7/22/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

import Foundation


class DataService {
    static let instance = DataService()
    
    private let categories = [
        CategoryNames(image: #imageLiteral(resourceName: "dairy"), title: "Dairy"),
        CategoryNames(image: #imageLiteral(resourceName: "fruits") , title: "Fruits"),
        CategoryNames(image: #imageLiteral(resourceName: "vegan"), title: "Vegan")
        
    ]
    
    private let Dairy = [
        ProductNames(title: "Cheese", image: #imageLiteral(resourceName: "cheese") , unit: "4 ounces", price: 4.00),
        ProductNames(title: "Milk", image:#imageLiteral(resourceName: "milk") , unit: "1 gallon", price: 3.25),
        ProductNames(title: "Ice Cream", image: #imageLiteral(resourceName: "iceCream") ,unit: "2 pints", price: 2.75)
       
    ]
    
//    private let Fruits = [
//        Product(title: "Devslopes Hoodie Gray", price: "$18", imageName: "hoodie01.png"),
//        Product(title: "Devslopes Hoodie Red", price: "$22", imageName: "hoodie02.png"),
//        Product(title: "Devslopes Hoodie Grey", price: "$22", imageName: "hoodie03.png"),
//        Product(title: "Devslopes Hoodie Black", price: "$22", imageName: "hoodie04.png")
//    ]
//
//    private let Vegans = [
//        Product(title: "Devslopes Logo Shirt Black", price: "$18", imageName: "shirt01.png"),
//        Product(title: "Devslopes Bage Shirt Light Grey", price: "$22", imageName: "shirt03.png"),
//        Product(title: "Devslopes Logo Shirt Red", price: "$22", imageName: "shirt02.png"),
//        Product(title: "Hustle Delegate Grey", price: "$22", imageName: "shirt03.png"),
//        Product(title: "Kickflip Studios Black", price: "$22", imageName: "shirt05.png")
//    ]
    
   
    
    
    func getCategories() -> [CategoryNames] {
        return categories
    }
    
    func getProducts(forCategoryTitl title: String) -> [ProductNames] {
        switch title {
        case "Dairy":
            return getDairy()
//        case "Fruits":
//            return getFruits()
//        case "Vegan":
//            return getVegan()
       default:
            return getDairy()
        }
        
        
        
    }
    
    func getDairy() -> [ProductNames] {
        return Dairy
    }
    
//    func getFruits() -> [Product] {
//        return hoodies
//    }
//
//    func getVegan() -> [Product] {
//        return shirts
//    }
//
 
    
    
    
    
    
}











