//
//  CurrencyCalc.swift
//  Shipper
//
//  Created by David Zheng on 7/23/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

import Foundation
class CurrencyCalc {
    let currency : Double?
    init (currency:Double) {
        self.currency = currency
    }


}

extension CurrencyCalc {
    func totalAmount( total: Double, quantity: Int) -> String {
        var newTotal = total
        return String(format: "%.2f",newTotal)

        
    }
}
