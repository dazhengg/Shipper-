//
//  ItemCartCell.swift
//  Shipper
//
//  Created by David Zheng on 7/23/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

// table view cells for cart
import UIKit
protocol ItemCartDelegate {
    func  updateCartItem(cell:ItemCartCell, quantity:Int )
}
class ItemCartCell: UITableViewCell {
    
    @IBOutlet weak var incrementButton: UIButton!
    @IBOutlet weak var decrementButton: UIButton!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    
    @IBOutlet weak var quantityLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    var delegate: ItemCartDelegate?
    var quantity: Int = 1
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func quantityUpdate(_ sender: UIButton) {
        if sender.tag == 0 {
            quantity += 1
        } else if quantity > 0 { //subtracting quantity
            quantity = quantity - 1
        }
        decrementButton.isEnabled = quantity > 0
        self.quantityLabel.text = String (describing: quantity)
        self.delegate?.updateCartItem(cell: self, quantity: quantity)
    }
}
