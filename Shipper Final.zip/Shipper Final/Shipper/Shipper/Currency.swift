//
//  Currency.swift
//  Shipper
//
//  Created by David Zheng on 7/23/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

import Foundation

struct Currency {
    var total: Double
}
