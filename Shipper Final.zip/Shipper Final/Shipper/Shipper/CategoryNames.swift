//
//  CategoryNames.swift
//  Shipper
//
//  Created by David Zheng on 7/22/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

import Foundation
import UIKit

class CategoryNames {
    var image :UIImage
    var title: String
    
    init (image: UIImage, title:String){
        self.image = image
        self.title = title
        
    }
}
