//
//  Cart.swift
//  Shipper
//
//  Created by David Zheng on 7/23/19.
//  Copyright © 2019 David Zheng. All rights reserved.
//

//import Foundation
//class Cart {
//    private(set) var items: [CartItem] = []
//
//}

import Foundation

class Cart {
    
    private(set) var items : [ItemCart] = []
}

extension Cart {
    var total: Double {
        get { return items.reduce(0.0) { value, item in
            value + item.curTotal
            }
        }
    }
    
    var totalQuantity : Int {
        get { return items.reduce(0) { value, item in
            value + item.quantity
            }
        }
    }
    
    func updateCart(with product: ProductNames) {
        if !self.contains(product: product) {
            self.add(product: product)
        } else {
            self.remove(product: product)
        }
    }
    
    func updateCart() {
        
        for item in self.items {
            if item.quantity == 0 {
                updateCart(with: item.product)
            }
        }
    }
    
    func add(product: ProductNames) {
        let item = items.filter { $0.product == product }
        
        if item.first != nil {
            item.first!.quantity += 1
        } else {
            items.append(ItemCart(product: product))
        }
    }
    
    func remove(product: ProductNames) {
        guard let index = items.index(where: { $0.product == product }) else { return}
        items.remove(at: index)
    }
    
    func contains(product: ProductNames) -> Bool {
        let item = items.filter { $0.product == product }
        return item.first != nil
    }
}
